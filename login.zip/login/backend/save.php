<?php
require_once('../session.php');
$_POST = json_decode(file_get_contents('php://input'), true);
if (
    isset($_SESSION['username'])
    && isset($_POST['marca'])
    && isset($_POST['modelo'])
    && isset($_POST['ano'])
    && isset($_POST['motorizacao'])
    && isset ($_POST['cor'])
    && isset ($_POST['placa'])
    && isset ($_POST['preco'])
   
) {
    require_once(BASE_PATH . '/backend/db.php');
    $marca = $_POST['marca'];
    $modelo = $_POST['modelo'];
    $ano = $_POST['ano'];
    $motorizacao = $_POST['motorizacao'];
    $cor = $_POST['cor'];
    $placa = $_POST['placa'];
    $preco = $_POST['preco'];
   

    if(!empty($_POST['id']))
        $sql = "UPDATE veiculos SET marca='$marca', modelo='$modelo', ano='$ano', motorizacao='$motorizacao', cor='$cor', placa='$placa', preco='$preco' WHERE id={$_POST['id']}";
    else
        $sql = "INSERT INTO veiculos VALUES (null, '$marca', '$modelo', '$ano', '$motorizacao', '$cor', '$placa', '$preco')";

    
    $result = $connection->query($sql);
    if ($result) {
        echo json_encode(array('mensagem' => 'ok'));
    } else {
        echo json_encode(array('mensagem' => 'erro'));
    }
} else {
    echo json_encode(array('mensagem' => 'Acesso Negado!'));
}
?>
