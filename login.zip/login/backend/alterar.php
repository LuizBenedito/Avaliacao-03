<?php
require_once '../session.php';

// Verifica se o usuário está logado
if (!isset($_SESSION['userid'])) {
    header('Location: '.BASE_URL.'/frontend/login.php');
    exit();
}

// Obtém o ID do usuário da sessão
$userId = $_SESSION['userid'];

// Obtém as informações do usuário a partir do ID
require_once(BASE_PATH.'/backend/db.php');
$sql = "SELECT * FROM usuarios WHERE id = $userId";
$result = $connection->query($sql);

if ($result->num_rows == 1) {
    $user = $result->fetch_object();
    $currentEmail = $user->email;
} else {
    // Usuário não encontrado
    echo 'Erro ao obter informações do usuário';
    exit();
}

    // Verifica se o formulário foi enviado para atualizar o email e a senha
    if (isset($_POST['new_email'], $_POST['new_password'], $_POST['confirm_password'])) {
    $newEmail = $_POST['new_email'];
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];

    // Validação dos campos
    if (empty($newEmail) || empty($newPassword) || empty($confirmPassword)) {
        $errorMessage = 'Todos os campos devem ser preenchidos.';
    } elseif ($newPassword !== $confirmPassword) {
        $errorMessage = 'As senhas não correspondem.';
    } else {
        // Atualiza o email e a senha do usuário no banco de dados
        $updateSql = "UPDATE usuarios SET email = '$newEmail', senha = '$newPassword' WHERE id = $userId";
        $updateResult = $connection->query($updateSql);

        if ($updateResult) {
            // Email e senha atualizados com sucesso
            $successMessage = 'Email e senha atualizados com sucesso.';
            $currentEmail = $newEmail; // Atualiza o email exibido na página
        } else {
            // Erro ao atualizar as informações
            $errorMessage = 'Erro ao atualizar o email e a senha.';
        }
    }
}
?>

<!DOCTYPE html>
<html>
<nav class="navbar navbar-expand-sm navbar-dark bg-dark navbar-custom">
    <a class="navbar-brand" href="../frontend/app.php">SuperCar</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown"
        aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="../frontend/app.php">Cadastrar Veículos</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= BASE_URL ?>/backend/alterar.php">Perfil</a>
            </li>
        </ul>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <?php echo $_SESSION['username']; ?>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item" href="<?= BASE_URL ?>/backend/logout.php">Sair</a>
                </div>
            </li>
        </ul>
    </div>
</nav>

<head>
    <title>Trocar Email e Senha</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <?php if (isset($errorMessage)) : ?>
                    <p style="color: red;"><?php echo $errorMessage; ?></p>
                <?php endif; ?>
                <?php if (isset($successMessage)) : ?>
                    <p style="color: green;"><?php echo $successMessage; ?></p>
                <?php endif; ?>
                <h1 class="mt-3">Trocar Email e Senha</h1>
                <?php if (isset($currentEmail)) : ?>
                    <p>Email Atual: <?php echo $currentEmail; ?></p>
                <?php endif; ?>
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="new_email">Novo Email:</label>
                        <input type="email" class="form-control" id="new_email" name="new_email" required>
                    </div>
                    <div class="form-group">
                        <label for="new_password">Nova Senha:</label>
                        <input type="password" class="form-control" id="new_password" name="new_password" required>
                    </div>
                    <div class="form-group">
                        <label for="confirm_password">Confirmar Nova Senha:</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </form>
            </div>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<style>
    .navbar-custom {
        height: 40px;
}

.dropdown-menu {
    min-width: 5px;
}


.dropdown-toggle:hover {
    background-color: #333;
}
</style>

