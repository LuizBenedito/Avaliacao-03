<?php
    $connection = new mysqli('localhost', 'root', '', 'veiculos');
    if ($connection->connect_errno) {
        printf("Connection failed: %s\n", $connection->connect_error);
        exit();
    }
?>