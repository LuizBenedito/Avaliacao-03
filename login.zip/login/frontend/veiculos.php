<!DOCTYPE html>
<div class="container">
  <h1>Cadastrar Veículos</h1>
  <input type="text" id="marca" placeholder="Marca">
  <input type="text" id="modelo" placeholder="Modelo">
  <input type="text" id="ano" placeholder="Ano">
  <input type="text" id="motorizacao" placeholder="Motorização. Ex: 1.0">
  <input type="text" id="cor" placeholder="Cor">
  <input type="text" id="placa" placeholder="Placa">
  <input type="text" id="preco" placeholder="Preço">
  <div id="botoes">
    <button id="salvar">Salvar</button>
    <button id="limpar">Limpar</button>
  </div>

  <div id="tabelaContainer">
    <table class="table table-bordered table-striped" id="tabela">
      <thead class="thead-dark">
        <tr>
          <th>ID</th>
          <th>Marca</th>
          <th>Modelo</th>
          <th>Ano</th>
          <th>Motorização</th>
          <th>Cor</th>
          <th>Placa</th>
          <th>Preço</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
      </tbody>
    </table>
  </div>
</div>
</html>

    <script>    
        loadVeiculos();
        document.getElementById('salvar').addEventListener('click', saveVeiculo);
        var veiculos = [];
        
        document.getElementById("limpar").addEventListener("click", function() {
        limparCampos();
    });

        function loadVeiculos() {
        let table = document.getElementById('tabela');
        fetch('<?= BASE_URL ?>/backend/dados.php?tabela=veiculos')
        .then(response => response.json())
        .then(data => {
            if (data.length > 0) {
                table.innerHTML = "<thead><tr><th>ID</th><th>Marca</th><th>Modelo</th><th>Ano</th><th>Motorização</th><th>Cor</th><th>Placa</th><th>Preço</th><th>Ações</th></tr></thead><tbody id=\"corpoTabelaProduto\"></tbody>";
                data.forEach(element => {
                    veiculos.push(element);
                    let botoes = "<div class='acoes'><button class='botao-editar' onclick='editarVeiculo("+element[0]+")'>Editar</button> <button class='botao-excluir' onclick='removerVeiculo(" + element[0] + ")'>Excluir</button></div>";
                    let linha = table.insertRow();
                    linha.insertCell().innerHTML = element[0];
                    linha.insertCell().innerHTML = element[1];
                    linha.insertCell().innerHTML = element[2];
                    linha.insertCell().innerHTML = element[3];
                    linha.insertCell().innerHTML = element[4];
                    linha.insertCell().innerHTML = element[5];
                    linha.insertCell().innerHTML = element[6];
                    linha.insertCell().innerHTML = element[7];
                    linha.insertCell().innerHTML = botoes;
                });
            } else {
                table.innerHTML = ""; 
            }
        })
        .catch(error => console.log(error));
}

        var veiculoEditando = null;

        function saveVeiculo() {
            let marca = document.getElementById('marca');
            let modelo = document.getElementById('modelo');
            let ano = document.getElementById('ano');
            let motorizacao = document.getElementById('motorizacao');
            let cor = document.getElementById('cor');
            let placa = document.getElementById('placa');
            let preco = document.getElementById('preco');

    
            if (marca.value === '' || modelo.value === '' || ano.value === '' ||
                 motorizacao.value === '' || cor.value === '' || placa.value === '' ||
                 preco.value === '') {
                alert('Por favor, preencha todos os campos antes de salvar.');
        return;
    }

    fetch('<?= BASE_URL ?>/backend/save.php', {
        method: "POST",
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
            marca: marca.value,
            modelo: modelo.value,
            ano: ano.value,
            motorizacao: motorizacao.value,
            cor: cor.value,
            placa: placa.value,
            preco: preco.value,
            id: (veiculoEditando) ? veiculoEditando : null
        }),
    })
    .then(response => response.text().then(data => {
        data = JSON.parse(data);
        if (data.mensagem == 'ok') {
            marca.value = '';
            modelo.value = '';
            ano.value = '';
            motorizacao.value = '';
            cor.value = '';
            placa.value = '';
            preco.value = '';
            veiculoEditando = null;
            veiculos = [];
            loadVeiculos();
        }
    }))
    .catch(error => console.log(error));
}

        function removerVeiculo(id) {

            if(!window.confirm('Deseja realmente excluir?'))
                return;
            
            fetch('<?= BASE_URL ?>/backend/remove.php', {
                    method: "POST",
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        "Access-Control-Allow-Origin": "*",
                    },
                    body: JSON.stringify({
                        id: id
                    }),
                })
                .then(
                    response => response.text().then(
                        data => {
                            data = JSON.parse(data);
                            if (data.mensagem == 'ok') {
                                loadVeiculos();
                            }
                        }
                    )
                )
                .catch(
                    error => console.log(error)
                );
        }

        function editarVeiculo(id) {
            let veiculo = veiculos.find(element => element[0] == id);
            document.getElementById('marca').value = veiculo[1];
            document.getElementById('modelo').value = veiculo[2];
            document.getElementById('ano').value = veiculo[3];
            document.getElementById('motorizacao').value = veiculo[4];
            document.getElementById('cor').value = veiculo[5];
            document.getElementById('placa').value = veiculo[6];
            document.getElementById('preco').value = veiculo[7];
            veiculoEditando = veiculo[0];
        }   

        function limparCampos() {
            document.getElementById("marca").value = "";
            document.getElementById("modelo").value = "";
            document.getElementById("ano").value = "";
            document.getElementById("motorizacao").value = "";
            document.getElementById("cor").value = "";
            document.getElementById("placa").value = "";
            document.getElementById("preco").value = "";
            veiculoEditando = null;
         }

    </script>
    
    <style>

    body {
        background: linear-gradient(to bottom, #87CEEB, #87CEEB);
}

    h1 {
        text-align: center;
        font-size: 24px;
        margin-bottom: 10px;
        color: #000000;
}

    .container {
        background-color: #fff;
        padding: 10px;
        border-radius: 5px;
        margin-bottom: 20px;
}

    .container h1 {
        font-size: 24px;
        margin-bottom: 20px;
}

    .container input[type="text"] {
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        display: block;
        margin: 0 auto 10px;
        padding: 5px;
        width: 300px;
}

    .container input[type="float"] {
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        display: block;
        margin: 0 auto 10px;
        padding: 5px;
        width: 300px;
}

    .container hr {
        margin-top: 20px;
        border: none;
        border-top: 1px solid #ccc;
}

    #botoes {
        text-align: center;
        margin-bottom: 10px;
         display: flex;
        justify-content: center;
}

    #salvar {
        width: 10%;
         padding: 15px;
         background-color: #4CAF50; 
         color: #ffffff;
         border: none;
         border-radius: 4px;
         cursor: pointer;
         display: inline-block;
         margin: 0 10px 10px 0;
         padding: 5px 10px;
}

    #salvar:hover {
        background-color: #45a049;
}

    #limpar {
        width: 10%;
        padding: 15px;
        background-color: #FFA500; 
        color: #ffffff;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        display: inline-block;
        margin: 0 10px 10px 0;
        padding: 5px 10px;
}

    #limpar:hover {
        background-color: #FF8C00;
}

    button.botao-editar {
         background-color: #4CAF50; 
         color: #ffffff;
         border: none;
         border-radius: 4px;
}       .botao-editar:hover {
         background-color: #45a049;
}

    button.botao-excluir {
        background-color: red;
        color: #ffffff;
        border: none;
        border-radius: 4px; 
}       .botao-excluir:hover {
        background-color: #FF3333;
}

    table {
        border-collapse: collapse;
        width: 60%;
        background-color: #f2f2f2;
        margin-left: auto;
        margin-right: auto; 
}

    table th,
    table td {
        text-align: center;
}

    .acoes {
        display: flex;
        justify-content: center;
}

    .acoes button {
        margin-left: 10px; 
}
</style>
