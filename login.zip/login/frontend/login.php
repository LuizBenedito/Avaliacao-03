<?php
require_once '../session.php';
if(isset($_SESSION['username']))
    header("location:".BASE_URL."/app.php");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Log In</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="<?=BASE_URL?>/frontend/assets/ajax.js"></script>

    <style>
        .container {
            max-width: 300px;
            margin: 50px auto;
            padding: 20px;
            background: linear-gradient(to bottom, #98FB98, #00FF00);
            border: 1px solid #ccc;
            border-radius: 4px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
    </style>
    
</head>
<body>
    <div class="container">
        <form action="<?=BASE_URL?>/backend/auth.php" method="post" onsubmit="return validateForm()">
            <div class="form-group">
                <label for="username">Usuário:</label>
                <input type="text" name="email" id="username" class="form-control" required />
            </div>
            <div class="form-group">
                <label for="password">Senha:</label>
                <input type="password" name="senha" id="password" class="form-control" required />
            </div>
            <button type="submit" class="btn btn-primary">Log In</button>
        </form>
    </div>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script>
        function validateForm() {
            var username = document.getElementById("username").value;
            var password = document.getElementById("password").value;

            if (username === '' || password === '') {
                alert("Por favor, preencha todos os campos.");
                return false;
            }
        }
    </script>
</body>
</html>
