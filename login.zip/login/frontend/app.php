<?php
require_once '../session.php';

if (!isset($_SESSION['username'])) {
    header('Location: ' . BASE_URL . '/frontend/login.php');
    exit;
}
?>
<!DOCTYPE html>
<html>

<!-- Inclua o jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Inclua o Popper.js (se necessário) -->
<script src="https://unpkg.com/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>

<!-- Inclua o Bootstrap JavaScript -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<head>
    <title>Cadastrar Veículos</title>
    <!-- meta refresh -->
    <meta http-equiv="refresh" content="<?= (SESSION_TIME + 1) ?>" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <!-- <script src="<?= BASE_URL ?>/frontend/assets/ajax.js"></script> -->
    <script>
        async function carregaDados() {
            let box = document.getElementById('dados');
            await fetch(new Request('<?= BASE_URL ?>/backend/dados.php'))
                .then(
                    function(response) {
                        response.text().then(
                            function(data) {
                                box.innerHTML = data;
                            }
                        );
                    }
                )
                .catch(
                    function(error) {
                        console.log(error);
                    }
                )
        }
    </script>
</head>

<body>
<nav class="navbar navbar-expand-sm navbar-dark bg-dark navbar-custom">
    <a class="navbar-brand" href="../frontend/app.php">SuperCar</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown"
        aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="../frontend/app.php">Cadastrar Veículos</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= BASE_URL ?>/backend/alterar.php">Perfil</a>
            </li>
        </ul>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <?php echo $_SESSION['username']; ?>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item" href="<?= BASE_URL ?>/backend/logout.php">Sair</a>
                </div>
            </li>
        </ul>
    </div>
</nav>
    <div class="container_bem_vindo">
        <h1>Bem-vindo, <?php echo $_SESSION['username']; ?>!</h1>
        <?php require_once BASE_PATH. '/frontend/veiculos.php'; ?>
    </div>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>

<style>
    .navbar-custom {    
        height: 40px;
}

    .dropdown-menu {
    min-width: 1px;
}

    .dropdown-toggle:hover {
    background-color: #333;
}
</style>
